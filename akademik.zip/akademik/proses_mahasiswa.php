<?php
include 'koneksi.php';
if ($_GET['proses'] == 'insert') {
        // query insert
    
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nim = $_POST['nim'];
    $nama_mhs = $_POST['nama_mhs'];
    $tanggal = $_POST['tgl_lahir'];
    $bulan = $_POST['bulan_lahir'];
    $tahun = $_POST['tahun_lahir'];
    $tgl_lahir = $tahun . '-' . $bulan . '-' . $tanggal;
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $hobi = implode(", ", $_POST['hobi']);
    $alamat = $_POST['alamat'];
    $prodi_id = $_POST['prodi_id'];

    $query = "INSERT INTO mahasiswa (nim, nama_mhs, tgl_lahir,prodi_id, jenis_kelamin, hobi, alamat) 
    VALUES ('$nim', '$nama_mhs', '$tgl_lahir','$prodi_id', '$jenis_kelamin', '$hobi', '$alamat')";
    if ($db->query($query) === TRUE) {
        header("Location: index.php?page=mahasiswa"); //redirect
        exit;
    } else {
        echo "Error: " . $query . "<br>" . $db->error;
    }
}  
}

if ($_GET['proses'] == 'update') {
    // query update
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $nim = $_POST['nim'];
        $nama_mhs = $_POST['nama_mhs'];
        $tanggal = $_POST['tanggal_lahir'];
        $bulan = $_POST['bulan_lahir'];
        $tahun = $_POST['tahun_lahir'];
        $tgl_lahir = $tahun . '-' . $bulan . '-' . $tanggal;
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $hobi = implode(", ", $_POST['hobi']);
        $alamat = $_POST['alamat'];
        $prodi_id = $_POST['prodi_id'];
    
        $query = "UPDATE mahasiswa
        SET nama_mhs='$nama_mhs', tgl_lahir='$tgl_lahir',prodi_id='$prodi_id', jenis_kelamin='$jenis_kelamin', hobi='$hobi', alamat='$alamat' WHERE nim='$nim'";
        if ($db->query($query) === TRUE) {
            header("Location: index.php?page=mahasiswa"); //redirect
            exit;
        } else {
            echo "Error: " . $query . "<br>" . $db->error;
        }
    }

}

if ($_GET['proses'] == 'delete') {
    // query delete
    
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $nim = $_GET['nim'];

    // Hapus data mahasiswa berdasarkan NIM
    $query = "DELETE FROM mahasiswa WHERE nim='$nim'";
    if ($db->query($query) === TRUE) {
        header("Location: index.php?page=mahasiswa");
        exit;
    } else {
        echo "Error: " . $query . "<br>" . $db->error;
    }
}
}