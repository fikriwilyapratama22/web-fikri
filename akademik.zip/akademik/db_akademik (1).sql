-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 04:56 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_akademik`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` varchar(11) NOT NULL,
  `nama_mhs` varchar(255) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `prodi_id` int(11) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `hobi` varchar(255) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama_mhs`, `tgl_lahir`, `prodi_id`, `jenis_kelamin`, `hobi`, `alamat`) VALUES
('1215002', 'Budi Gunawan', '2003-06-05', 4, 'Laki-laki', 'Renang, Membaca, Olahraga', 'Mata Aia'),
('2201091017', 'Fikri WP', '2009-10-15', 15, 'Laki-laki', 'Renang, Membaca, Olahraga', 'Padang'),
('2201091876', 'RERE', '2008-11-17', 14, 'Perempuan', 'Membaca', 'Padang'),
('2201092023', 'Basmian', '2008-10-18', 8, 'Perempuan', 'Renang', 'Padang'),
('2201092345', 'Salit', '2007-11-17', 16, 'Laki-laki', 'Renang', 'Dumai'),
('2201096431', 'Abina', '2008-10-17', 14, 'Perempuan', 'Membaca', 'Padang'),
('2201096543', 'zaky', '1981-06-15', 14, 'Laki-laki', 'Membaca, Olahraga', 'Surabaya'),
('2201098732', 'sarety', '2007-11-17', 4, 'Laki-laki', 'Membaca', 'Padang'),
('2201098761', 'Bonar', '2008-11-15', 15, 'Laki-laki', 'Renang', 'Padang'),
('2201098776', 'Dodi', '2011-11-17', 15, 'Laki-laki', 'Membaca', 'Tokyo'),
('2201099923', 'Filo', '2008-11-16', 16, 'Laki-laki', 'Renang, Olahraga', 'Padang'),
('22011098621', 'Alan', '2010-08-29', 4, 'Laki-laki', 'Renang', 'Padang'),
('2301093008', 'Shalu', '2008-06-06', 16, 'Perempuan', 'Renang', 'Padang');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa2`
--

CREATE TABLE `mahasiswa2` (
  `nim` varchar(11) NOT NULL,
  `nama_mahasiswa` varchar(50) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `prodi_id` int(11) NOT NULL,
  `alamat` text NOT NULL,
  `hobi` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `mahasiswa2`
--

INSERT INTO `mahasiswa2` (`nim`, `nama_mahasiswa`, `tanggal_lahir`, `prodi_id`, `alamat`, `hobi`, `jenis_kelamin`) VALUES
('09743457', 'alim', '2018-06-06', 15, 'jepang', 'Berenang', 'Laki-laki'),
('123456789', 'Rina', '2013-02-06', 14, 'Binuang', 'Menari, Berenang', 'Perempuan'),
('12345909', 'mawar', '2018-06-04', 15, 'ngalau', 'Berenang', 'Perempuan'),
('220101934', 'Roy', '2012-07-07', 14, 'unp', 'Berenang, Futsal', 'Laki-laki'),
('22010910068', 'BENI', '2019-04-04', 4, 'pauh', 'Menari', 'Laki-laki'),
('2201091007', 'ester', '2019-04-04', 8, 'jln moh hatta', 'Futsal', 'Perempuan'),
('2201091017', 'fikri', '2022-02-02', 8, 'Binuang', 'Menari', 'Laki-laki'),
('2201092026', 'Tita', '2004-01-24', 14, 'ngalau', 'Menari, Berenang, Futsal', 'Perempuan'),
('2201092032', 'Elsa', '2018-05-03', 15, 'kapalo koto', 'Menari', 'Perempuan'),
('2201092035', 'ester', '2015-05-06', 8, 'jamsek', 'Menari, Travelling', 'Perempuan'),
('5875890', 'jerom', '2018-06-06', 8, 'jakarta', 'Berenang', 'Laki-laki'),
('59849098765', 'pekla', '2019-04-04', 8, 'jakarta', 'Menari', 'Laki-laki');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna2`
--

CREATE TABLE `pengguna2` (
  `nim` int(10) NOT NULL,
  `email` varchar(64) NOT NULL,
  `nama_mahasiswa` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pengguna2`
--

INSERT INTO `pengguna2` (`nim`, `email`, `nama_mahasiswa`, `password`, `level`) VALUES
(1, 'basmidalaia1205@gmail.com', 'Basmida', 'e10adc3949ba59abbe56e057f20f883e', 'admin'),
(2, 'user@gmail.com', 'Basmida', 'e10adc3949ba59abbe56e057f20f883e', 'user'),
(3, 'fikri@gmail.com', 'fikri', '81dc9bdb52d04dc20036dbd8313ed055', 'user2');

-- --------------------------------------------------------

--
-- Table structure for table `prodi`
--

CREATE TABLE `prodi` (
  `id` int(11) NOT NULL,
  `nama_prodi` varchar(64) NOT NULL,
  `jenjang_studi` enum('D3','D4','S1','S2') NOT NULL,
  `keterangan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `prodi`
--

INSERT INTO `prodi` (`id`, `nama_prodi`, `jenjang_studi`, `keterangan`) VALUES
(4, 'Tekom', 'D3', 'Akreditasi A'),
(8, 'TRPL', 'D3', 'Akreditasi cccccccc'),
(14, 'Teknik Elektro', 'D4', 'Akrediasi A'),
(15, 'Akutansi', 'S1', 'Akreditasi B'),
(16, 'Manajemen Informatika', 'D3', 'Akreditasi A'),
(18, 'IKN', 'S1', 'KKskdqwd');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(50) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `nama`, `password`, `level`) VALUES
('admin', 'Administrator1', '21232f297a57a5a743894a0e4a801fc3', 'admin'),
('fikriwilyapratama', 'fikri 1', '202cb962ac59075b964b07152d234b70', 'admin'),
('user1', 'user1', '202cb962ac59075b964b07152d234b70', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`),
  ADD KEY `prodi_id` (`prodi_id`);

--
-- Indexes for table `mahasiswa2`
--
ALTER TABLE `mahasiswa2`
  ADD PRIMARY KEY (`nim`),
  ADD KEY `prodi_id` (`prodi_id`);

--
-- Indexes for table `pengguna2`
--
ALTER TABLE `pengguna2`
  ADD PRIMARY KEY (`nim`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `prodi`
--
ALTER TABLE `prodi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengguna2`
--
ALTER TABLE `pengguna2`
  MODIFY `nim` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `prodi`
--
ALTER TABLE `prodi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `mahasiswa_ibfk_1` FOREIGN KEY (`prodi_id`) REFERENCES `prodi` (`id`);

--
-- Constraints for table `mahasiswa2`
--
ALTER TABLE `mahasiswa2`
  ADD CONSTRAINT `mahasiswa2_ibfk_1` FOREIGN KEY (`prodi_id`) REFERENCES `prodi` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
